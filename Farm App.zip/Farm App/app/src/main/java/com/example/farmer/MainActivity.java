package com.example.farmer;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    Bitmap bitmap;
    Button save, chooseImage;
    EditText name;
    int REQUEST_CODE = 123;
    EditText cows, pigs, sheep;
    Button viewData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_main);
        }catch (Exception e){
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }

        imageView = findViewById(R.id.imageView);
        save = findViewById(R.id.save);
        chooseImage = findViewById(R.id.chooseImage);
        name = findViewById(R.id.name);
        cows = findViewById(R.id.cows);
        pigs = findViewById(R.id.pigs);
        sheep = findViewById(R.id.sheep);
        save = findViewById(R.id.save);
        viewData = findViewById(R.id.viewData);
        chooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectImage();
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getName = name.getText().toString();
                JSONObject dataObj = new JSONObject();
                String getCows = cows.getText().toString();
                String getPigs = pigs.getText().toString();
                String getSheep = sheep.getText().toString();
                if (getName.equals("") || getCows.equals("") || getPigs.equals("") || getSheep.equals("")){
                    Toast.makeText(getApplicationContext(), "All field are required!!", Toast.LENGTH_LONG).show();
                }else{
                    try {
                        dataObj.put("name", getName);
                        dataObj.put("cows", getCows);
                        dataObj.put("pigs", getPigs);
                        dataObj.put("sheep", getSheep);

                        String dataString = dataObj.toString();

                        SharedPreferences.Editor sharedPreferences = getSharedPreferences("farmerData", MODE_PRIVATE).edit();
                        sharedPreferences.putString("farmerData", dataString);
                        sharedPreferences.apply();

                        Toast.makeText(getApplicationContext(), "Data saved successfully!!", Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }

                }

            }
        });
        viewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, DataActivity.class);
                startActivity(intent);
            }
        });
    }
    public void selectImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction("android.intent.action.GET_CONTENT");
        startActivityForResult(intent, this.REQUEST_CODE);
    }
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == this.REQUEST_CODE && resultCode == -1 && data != null) {
            try {
                this.bitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), data.getData());
                this.imageView.setImageBitmap(this.bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}