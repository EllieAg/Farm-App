package com.example.farmer;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class DataActivity extends AppCompatActivity {
    TextView name, cows, pigs, sheep, special, desc;
    ImageView imageView;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        name = findViewById(R.id.name);
        cows = findViewById(R.id.cows);
        pigs = findViewById(R.id.pigs);
        sheep = findViewById(R.id.sheep);
        special = findViewById(R.id.special);
        desc = findViewById(R.id.desc);
        imageView = findViewById(R.id.imageView);

        SharedPreferences sharedPreferences = getSharedPreferences("farmerData", MODE_PRIVATE);
        String data = sharedPreferences.getString("farmerData", "");

        Map<String, Integer> map = new HashMap<>();

        try {
            JSONObject jsonObject = new JSONObject(data);
            name.setText(jsonObject.getString("name"));
            cows.setText(jsonObject.getString("cows"));
            pigs.setText(jsonObject.getString("pigs"));
            sheep.setText(jsonObject.getString("sheep"));

            map.put("cows", Integer.valueOf(jsonObject.getString("cows")));
            map.put("pigs", Integer.valueOf(jsonObject.getString("pigs")));
            map.put("sheep", Integer.valueOf(jsonObject.getString("sheep")));
        } catch (JSONException e) {
            e.printStackTrace();
        }
        String animal = "";
        int maxValueInMap=(Collections.max(map.values()));
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue()==maxValueInMap) {
                animal = entry.getKey();
            }
        }
        switch (animal) {
            case "cows":
                special.setText("Special Facts About Cows");
                desc.setText("Cows can smell something up to 6 miles away.");
                imageView.setImageResource(R.drawable.cow);
                break;
            case "pigs":
                special.setText("Special Facts About Pigs");
                desc.setText("Pigs are among the smartest of all domesticated animals and are smarter than dogs.");
                imageView.setImageResource(R.drawable.pig);
                break;
            case "sheep":
                special.setText("Special Facts About Sheep");
                desc.setText("An adult male sheep is called a ram, while an adult female is called a ewe.");
                imageView.setImageResource(R.drawable.sheep);
                break;
        }

    }
}